package com.example.gasolineStation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
