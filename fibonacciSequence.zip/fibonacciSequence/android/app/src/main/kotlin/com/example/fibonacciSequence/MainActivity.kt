package com.example.fibonacciSequence

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
